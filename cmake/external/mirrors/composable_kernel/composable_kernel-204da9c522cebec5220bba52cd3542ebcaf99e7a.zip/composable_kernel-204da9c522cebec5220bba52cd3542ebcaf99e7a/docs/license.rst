.. meta::
  :description: Composable Kernel documentation and API reference library
  :keywords: composable kernel, CK, ROCm, API, documentation

.. _license:

********************************************************************
License
********************************************************************

.. include:: ../LICENSE