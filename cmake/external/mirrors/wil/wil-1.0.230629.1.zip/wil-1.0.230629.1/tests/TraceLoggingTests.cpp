#include <wil/Tracelogging.h>

// Just verify that Tracelogging.h compiles.