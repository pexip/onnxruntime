# onnx.parser

## parse_node

```{eval-rst}
.. autofunction:: onnx.parser.parse_node
```

## parse_function

```{eval-rst}
.. autofunction:: onnx.parser.parse_function
```

## parse_graph

```{eval-rst}
.. autofunction:: onnx.parser.parse_graph
```

## parse_model

```{eval-rst}
.. autofunction:: onnx.parser.parse_model
```
