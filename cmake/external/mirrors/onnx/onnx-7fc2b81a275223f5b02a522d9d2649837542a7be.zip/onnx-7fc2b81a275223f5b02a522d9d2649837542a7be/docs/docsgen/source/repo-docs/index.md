<!--
Copyright (c) ONNX Project Contributors

SPDX-License-Identifier: Apache-2.0
-->

# ONNX Repository Documentation

Markdown documentation from the [ONNX repository](https://github.com/onnx/onnx/tree/main/docs).

```{toctree}
:maxdepth: 1
:glob:

*
```
