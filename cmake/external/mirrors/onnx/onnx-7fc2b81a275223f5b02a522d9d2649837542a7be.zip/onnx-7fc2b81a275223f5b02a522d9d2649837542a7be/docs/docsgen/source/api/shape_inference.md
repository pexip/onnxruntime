# onnx.shape_inference

## infer_shapes

```{eval-rst}
.. autofunction:: onnx.shape_inference.infer_shapes
```

## infer_shapes_path

```{eval-rst}
.. autofunction:: onnx.shape_inference.infer_shapes_path
```

## infer_node_outputs

```{eval-rst}
.. autofunction:: onnx.shape_inference.infer_node_outputs
```

## infer_function_output_types

```{eval-rst}
.. autofunction:: onnx.shape_inference.infer_function_output_types
```
