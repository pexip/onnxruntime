# onnx._custom_element_types

```{eval-rst}
.. automodule:: onnx._custom_element_types
    :members:
    :undoc-members:
```
