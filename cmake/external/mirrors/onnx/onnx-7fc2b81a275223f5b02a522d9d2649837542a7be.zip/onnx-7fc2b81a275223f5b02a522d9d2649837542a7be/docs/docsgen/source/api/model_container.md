# onnx.model_container


## ModelContainer

```{eval-rst}
.. autoclass:: onnx.model_container.ModelContainer
    :members:
```

## make_large_model

```{eval-rst}
.. autofunction:: onnx.model_container.make_large_model
```

## make_large_tensor_proto

```{eval-rst}
.. autofunction:: onnx.model_container.make_large_tensor_proto
```
