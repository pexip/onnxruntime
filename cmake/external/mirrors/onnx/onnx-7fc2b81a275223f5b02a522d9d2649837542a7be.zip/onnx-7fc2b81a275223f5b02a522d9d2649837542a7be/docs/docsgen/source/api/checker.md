# onnx.checker

## CheckerContext

```{eval-rst}
.. autoclass:: onnx.checker.DEFAULT_CONTEXT
    :members:
```

## The `onnx.checker` module

```{eval-rst}
.. automodule:: onnx.checker
    :members:
    :undoc-members:
    :show-inheritance:
```
