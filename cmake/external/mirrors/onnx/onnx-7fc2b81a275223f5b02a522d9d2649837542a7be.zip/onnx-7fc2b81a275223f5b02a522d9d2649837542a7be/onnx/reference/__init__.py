# Copyright (c) ONNX Project Contributors
#
# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

__all__ = ["ReferenceEvaluator"]

from onnx.reference.reference_evaluator import ReferenceEvaluator
