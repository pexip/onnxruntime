---
name: New Operator
about: Create a new operator that does not currently exist in the ONNX.
title: ''
labels: 'operator'
assignees: ''



---
# New Operator

### Describe the operator
<!-- Why is this operator necessary? What does it accomplish? -->

### Can this operator be constructed using existing onnx operators?
<!-- If so, why not add it as a function? -->

### Is this operator used by any model currently? Which one?

### Are you willing to contribute it? (Y/N)

### Notes
<!-- Any additional information -->
