---
name: Missing Layer Type
about: Request support for a missing layer type
title: ''
labels: missing layer type
assignees: ''

---

- Name of layer type:
- Is this a PyTorch or a TensorFlow layer type:
- Your version of coremltools:
- Your version of PyTorch/TensorFlow:
- Impact of supporting this layer type. Why is adding support for this layer type important? Is it necessary to support a popular model or use case?
